package com.oujian.graduation.net.req;

/**
 * Created by DIY on 2017/4/24.
 */

public class ChatReq {
    private String key;
    private String info;

    public String getKey() {
        return key;
    }

    public void setKey(String key) {
        this.key = key;
    }

    public String getInfo() {
        return info;
    }

    public void setInfo(String info) {
        this.info = info;
    }
}
