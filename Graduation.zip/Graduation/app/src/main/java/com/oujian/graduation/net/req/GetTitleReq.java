package com.oujian.graduation.net.req;

/**
 * Created by Administrator on 2017-05-06.
 */

public class GetTitleReq {
    private String title;

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }
}
