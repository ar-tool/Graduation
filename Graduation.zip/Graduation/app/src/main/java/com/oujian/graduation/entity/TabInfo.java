package com.oujian.graduation.entity;

/**
 * Created by yi on 2017-03-20.
 */

public class TabInfo {
    public String tag = "";
    public String label = "";
    public Class clss = null;
    public int drawableId = 0;
}
