package com.oujian.graduation.view;

/**
 * @author yi
 */
public interface ISpanClick {
    public void onClick(int position);
}
